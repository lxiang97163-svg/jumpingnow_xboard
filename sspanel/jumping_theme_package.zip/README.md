# SSPanel-UIM Jumping Theme (Full Version)

A modern, Apple-style minimalist theme for SSPanel-UIM, based on Tabler UI and Phosphor Icons.

## Features

- **Design**: Clean, "Jumping" aesthetic inspired by Apple's design language.
- **Icons**: Replaced all Tabler Icons with Phosphor Icons for a more refined look.
- **Dark Mode**: Native dark mode support with auto-detection and manual toggle (persisted via localStorage).
- **Responsive**: Fully responsive layout for mobile, tablet, and desktop.
- **Coverage**: Complete redesign of:
    - Landing Page
    - Authentication Pages (Login, Register, MFA, etc.)
    - User Dashboard (All pages)
    - Admin Dashboard (All pages)
    - Payment Gateways
    - Error Pages

## Installation

1. **Upload Files**:
   - Copy the contents of `public/theme/jumping/` to your SSPanel-UIM `public/theme/jumping/` directory.
   - Copy the contents of `resources/views/jumping/` to your SSPanel-UIM `resources/views/jumping/` directory.

2. **Configuration**:
   - Open your SSPanel-UIM configuration file (usually `config/.config.php`).
   - Set `$_ENV['theme']` to `'jumping'`.

3. **Dependencies**:
   - This theme relies on standard SSPanel-UIM dependencies.
   - Ensure `htmx`, `qrcode.js`, `clipboard.js` are available (served via CDN in the templates).

## Directory Structure

```
sspanel_theme_jumping_full/
├── public/
│   └── theme/
│       └── jumping/
│           ├── css/
│           │   └── style.css      # Main stylesheet with custom variables and overrides
│           └── assets/            # (Optional) Additional assets if needed
└── resources/
    └── views/
        └── jumping/
            ├── admin/             # Admin panel templates
            ├── auth/              # Authentication templates
            ├── gateway/           # Payment gateway templates
            ├── password/          # Password reset templates
            ├── user/              # User panel templates
            ├── 404.tpl            # Error pages
            ├── 405.tpl
            ├── 500.tpl
            ├── footer.tpl         # Global footer
            ├── header.tpl         # Global header
            └── index.tpl          # Landing page
```

## Customization

- **Colors & Fonts**: Edit `public/theme/jumping/css/style.css` to modify CSS variables like `--primary-color`, `--bg-dark`, etc.
- **Logo**: The theme expects a logo at `/images/uim-logo-round_48x48.png`. You can replace this path in `header.tpl` files.

## Credits

- Based on [Tabler](https://tabler.io/).
- Icons by [Phosphor Icons](https://phosphoricons.com/).
