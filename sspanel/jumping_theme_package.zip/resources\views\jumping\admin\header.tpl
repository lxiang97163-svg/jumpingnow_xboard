<!doctype html>
<html lang="zh">

<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"/>
    <meta name="format-detection" content="telephone=no"/>
    <title>{$config['appName']} - 管理后台</title>
    <!-- CSS files -->
    <link href="//{$config['jsdelivr_url']}/npm/@tabler/core@latest/dist/css/tabler.min.css" rel="stylesheet"/>
    <link href="/theme/jumping/css/style.css" rel="stylesheet"/>
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <!-- JS files -->
    <script src="/assets/js/fuck.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/qrcode_js@latest/qrcode.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/clipboard@latest/dist/clipboard.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/jquery/dist/jquery.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/htmx.org@latest/dist/htmx.min.js"></script>
    <style>
        .navbar-vertical { background: #fff; border-right: 1px solid #e6e8eb; }
        .nav-link-title { font-weight: 500; }
        .page-wrapper { background: #f4f6f8; min-height: 100vh; }
        
        [data-bs-theme="dark"] .navbar-vertical {
            background: #1e293b;
            border-right: 1px solid #334155;
        }
    </style>
</head>

<body class="dashboard-body">
<div class="page">
    <!-- Sidebar -->
    <aside class="navbar navbar-vertical navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <h1 class="navbar-brand navbar-brand-autodark">
                <a href="/admin" style="text-decoration: none; color: #007aff; font-weight: 800; display: flex; align-items: center; gap: 10px;">
                    <img src="/images/uim-logo-round_48x48.png" height="32" alt="Logo">
                    管理后台
                </a>
            </h1>
            <div class="navbar-nav flex-row d-lg-none">
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown">
                        <span class="avatar avatar-sm" style="background-image: url({$user->dice_bear})"></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <a href="/user/profile" class="dropdown-item">账户</a>
                        <a href="/user/logout" class="dropdown-item">登出</a>
                    </div>
                </div>
            </div>
            <div class="collapse navbar-collapse" id="sidebar-menu">
                <ul class="navbar-nav pt-lg-3">
                    <li class="nav-item">
                        <a class="nav-link" href="/admin">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-house"></i></span>
                            <span class="nav-link-title">概况</span>
                        </a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-manage" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-sliders"></i></span>
                            <span class="nav-link-title">管理</span>
                        </a>
                        <div class="dropdown-menu">
                            <div class="dropend">
                                <a class="dropdown-item dropdown-toggle" href="#" data-bs-toggle="dropdown" data-bs-auto-close="outside" role="button" aria-expanded="false">
                                    <i class="ph ph-gear me-2"></i> 设置
                                </a>
                                <div class="dropdown-menu">
                                    <a href="/admin/setting/billing" class="dropdown-item">财务</a>
                                    <a href="/admin/setting/email" class="dropdown-item">邮件</a>
                                    <a href="/admin/setting/support" class="dropdown-item">客服</a>
                                    <a href="/admin/setting/captcha" class="dropdown-item">验证</a>
                                    <a href="/admin/setting/reg" class="dropdown-item">注册</a>
                                    <a href="/admin/setting/ref" class="dropdown-item">邀请</a>
                                    <a href="/admin/setting/im" class="dropdown-item">IM</a>
                                    <a href="/admin/setting/sub" class="dropdown-item">订阅</a>
                                    <a href="/admin/setting/cron" class="dropdown-item">定时任务</a>
                                    <a href="/admin/setting/feature" class="dropdown-item">其他设置</a>
                                </div>
                            </div>
                            <a class="dropdown-item" href="/admin/user">
                                <i class="ph ph-users me-2"></i> 用户
                            </a>
                            <a class="dropdown-item" href="/admin/node">
                                <i class="ph ph-server me-2"></i> 节点
                            </a>
                            <a class="dropdown-item" href="/admin/system">
                                <i class="ph ph-wrench me-2"></i> 系统
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-operation" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-chats-circle"></i></span>
                            <span class="nav-link-title">运营</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/admin/announcement">
                                <i class="ph ph-megaphone me-2"></i> 公告
                            </a>
                            <a class="dropdown-item" href="/admin/ticket">
                                <i class="ph ph-ticket me-2"></i> 工单
                            </a>
                            <a class="dropdown-item" href="/admin/docs">
                                <i class="ph ph-book me-2"></i> 文档
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-log" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-notebook"></i></span>
                            <span class="nav-link-title">日志</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/admin/login">
                                <i class="ph ph-sign-in me-2"></i> 登录
                            </a>
                            <a class="dropdown-item" href="/admin/subscribe">
                                <i class="ph ph-rss me-2"></i> 订阅
                            </a>
                            <a class="dropdown-item" href="/admin/payback">
                                <i class="ph ph-hand-coins me-2"></i> 返利
                            </a>
                            <a class="dropdown-item" href="/admin/money">
                                <i class="ph ph-wallet me-2"></i> 余额
                            </a>
                            <a class="dropdown-item" href="/admin/gateway">
                                <i class="ph ph-credit-card me-2"></i> 支付网关
                            </a>
                            <a class="dropdown-item" href="/admin/online">
                                <i class="ph ph-globe me-2"></i> 在线IP
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-audit" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-shield-check"></i></span>
                            <span class="nav-link-title">审计</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/admin/detect">
                                <i class="ph ph-prohibit me-2"></i> 规则
                            </a>
                            <a class="dropdown-item" href="/admin/detect/log">
                                <i class="ph ph-list-magnifying-glass me-2"></i> 碰撞记录
                            </a>
                            <a class="dropdown-item" href="/admin/detect/ban">
                                <i class="ph ph-user-minus me-2"></i> 封禁记录
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-finance" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-currency-circle-dollar"></i></span>
                            <span class="nav-link-title">财务</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/admin/product">
                                <i class="ph ph-shopping-bag me-2"></i> 商品
                            </a>
                            <a class="dropdown-item" href="/admin/order">
                                <i class="ph ph-receipt me-2"></i> 订单
                            </a>
                            <a class="dropdown-item" href="/admin/invoice">
                                <i class="ph ph-file-text me-2"></i> 账单
                            </a>
                            <a class="dropdown-item" href="/admin/coupon">
                                <i class="ph ph-tag me-2"></i> 优惠码
                            </a>
                            <a class="dropdown-item" href="/admin/giftcard">
                                <i class="ph ph-gift me-2"></i> 礼品卡
                            </a>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="/user">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-arrow-u-up-left"></i></span>
                            <span class="nav-link-title">返回用户中心</span>
                        </a>
                    </li>
                </ul>

                <!-- Bottom User Menu (Desktop) -->
                <div class="mt-auto d-none d-lg-block mb-3">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-reset text-decoration-none" data-bs-toggle="dropdown">
                            <span class="avatar avatar-sm" style="background-image: url({$user->dice_bear})"></span>
                            <div class="d-none d-xl-block ps-2">
                                <div>{$user->user_name}</div>
                                <div class="mt-1 small text-muted">管理员</div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                            <a href="#" class="dropdown-item" onclick="toggleTheme(); return false;">
                                <i class="ph ph-moon me-2" id="theme-icon"></i> 切换主题
                            </a>
                            <a href="/user/logout" class="dropdown-item">登出</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <div class="page-wrapper">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <div class="page-pretitle">
                            管理
                        </div>
                        <h2 class="page-title">
                            {$config['appName']} 后台
                        </h2>
                    </div>
                </div>
            </div>
        </div>
