{include file='header.tpl'}

<script src="https://unpkg.com/@simplewebauthn/browser/dist/bundle/index.umd.min.js"></script>

<body class="d-flex flex-column bg-white">
<div class="row g-0 flex-fill">
    <div class="col-12 col-lg-6 col-xl-4 border-top-wide border-primary d-flex flex-column justify-content-center">
        <div class="container container-tight my-5 px-lg-5">
            <div class="text-center mb-4">
                <a href="/" class="navbar-brand navbar-brand-autodark">
                    <span class="logo">{$config['appName']}</span>
                </a>
            </div>
            <h2 class="h3 text-center mb-3">欢迎回来</h2>
            <div class="mb-3">
                <label class="form-label">邮箱</label>
                <input id="email" type="email" class="form-control" placeholder="your@email.com">
            </div>
            <div class="mb-2">
                <label class="form-label">
                    密码
                    <span class="form-label-description">
                        <a href="/password/reset">忘记密码</a>
                    </span>
                </label>
                <div class="input-group input-group-flat">
                    <input id="password" type="password" class="form-control" autocomplete="off" placeholder="您的密码">
                </div>
            </div>
            <div class="mb-2">
                <label class="form-check">
                    <input id="remember_me" type="checkbox" class="form-check-input"/>
                    <span class="form-check-label">记住此设备</span>
                </label>
            </div>
            <div class="mb-3">
                <div class="input-group mb-3">
                {if $public_setting['enable_login_captcha']}
                    {include file='captcha/div.tpl'}
                {/if}
                </div>
            </div>
            <div class="form-footer">
                <button class="btn btn-primary w-100 mb-3"
                        hx-post="/auth/login" hx-swap="none" hx-vals='js:{
                            {if $public_setting['enable_login_captcha']}
                                {include file='captcha/ajax.tpl'}
                            {/if}
                            email: document.getElementById("email").value,
                            password: document.getElementById("password").value,
                            remember_me: document.getElementById("remember_me").checked,
                         }'>
                    登录
                </button>
                <button class="btn btn-ghost-primary w-100" id="webauthnLogin">
                    <i class="ph ph-fingerprint me-2"></i> 使用 WebAuthn 登录
                </button>
            </div>
            <div class="text-center text-secondary mt-3">
                还没有账户？ <a href="/auth/register" tabindex="-1">立即注册</a>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6 col-xl-8 d-none d-lg-block">
        <div class="bg-cover h-100 min-vh-100" style="background-image: url(https://source.unsplash.com/random/1920x1080/?abstract,technology)"></div>
    </div>
</div>

{if $public_setting['enable_login_captcha']}
    {include file='captcha/js.tpl'}
{/if}

{include file='footer.tpl'}

{literal}
    <script>
        const { startAuthentication } = SimpleWebAuthnBrowser;
        document.getElementById('webauthnLogin').addEventListener('click', async () => {
            const resp = await fetch('/auth/webauthn');
            const options = await resp.json();
            let asseResp;
            try {
                asseResp = await startAuthentication({ optionsJSON: options });
            } catch (error) {
                document.getElementById("fail-message").innerHTML = error;
                throw error;
            }
            const verificationResp = await fetch('/auth/webauthn', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(asseResp),
            });
            const verificationJSON = await verificationResp.json();
            if (verificationJSON.ret === 1) {
                document.getElementById("success-message").innerHTML = verificationJSON.msg;
                successDialog.show();
                window.location.href = verificationJSON.redir;
            } else {
                document.getElementById("fail-message").innerHTML = verificationJSON.msg;
                failDialog.show();
            }
        });
    </script>
{/literal}
