{include file='header.tpl'}

<body class="d-flex flex-column bg-white">
<div class="row g-0 flex-fill">
    <div class="col-12 col-lg-6 col-xl-4 border-top-wide border-primary d-flex flex-column justify-content-center">
        <div class="container container-tight my-5 px-lg-5">
            <div class="text-center mb-4">
                <a href="/" class="navbar-brand navbar-brand-autodark">
                    <span class="logo">{$config['appName']}</span>
                </a>
            </div>
            {if $public_setting['reg_mode'] !== 'close'}
                <h2 class="h3 text-center mb-3">创建新账户</h2>
                <div class="mb-3">
                    <label class="form-label">昵称</label>
                    <input id="name" type="text" class="form-control" placeholder="怎么称呼您">
                </div>
                <div class="mb-3">
                    <label class="form-label">邮箱</label>
                    <input id="email" type="email" class="form-control" placeholder="your@email.com">
                </div>
                {if $public_setting['reg_email_verify']}
                <div class="mb-3">
                    <label class="form-label">验证码</label>
                    <div class="input-group mb-2">
                        <input id="emailcode" type="text" class="form-control" placeholder="邮箱验证码">
                        <button id="send-verify-email" class="btn text-blue" type="button"
                                hx-post="/auth/send" hx-swap="none" hx-disabled-elt="this"
                                hx-vals='js:{ email: document.getElementById("email").value }'>
                            获取
                        </button>
                    </div>
                </div>
                {/if}
                <div class="mb-3">
                    <label class="form-label">密码</label>
                    <div class="input-group input-group-flat">
                        <input id="password" type="password" class="form-control" placeholder="设置密码">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">确认密码</label>
                    <div class="input-group input-group-flat">
                        <input id="confirm_password" type="password" class="form-control" placeholder="再次输入密码">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">邀请码</label>
                    <div class="input-group input-group-flat">
                        <input id="invite_code" type="text" class="form-control"
                               placeholder="{if $public_setting['reg_mode'] === 'open'}（可选）{else}（必填）{/if}"
                               value="{$invite_code}">
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-check">
                        <input id="tos" type="checkbox" class="form-check-input"/>
                        <span class="form-check-label">
                            我已阅读并同意 <a href="/tos" tabindex="-1"> 服务条款与隐私政策 </a>
                        </span>
                    </label>
                </div>
                <div class="mb-3">
                    <div class="input-group mb-3">
                    {if $public_setting['enable_reg_captcha']}
                        {include file='captcha/div.tpl'}
                    {/if}
                    </div>
                </div>
                <div class="form-footer">
                    <button class="btn btn-primary w-100"
                            hx-post="/auth/register" hx-swap="none" hx-vals='js:{
                                {if $public_setting['reg_email_verify']}
                                    emailcode: document.getElementById("emailcode").value,
                                {/if}
                                {if $public_setting['enable_reg_captcha']}
                                    {include file='captcha/ajax.tpl'}
                                {/if}
                                name: document.getElementById("name").value,
                                email: document.getElementById("email").value,
                                password: document.getElementById("password").value,
                                confirm_password: document.getElementById("confirm_password").value,
                                invite_code: document.getElementById("invite_code").value,
                                tos: document.getElementById("tos").checked,
                             }'>
                        注册
                    </button>
                </div>
            {else}
                <div class="text-center">
                    <p>还没有开放注册，过两天再来看看吧</p>
                </div>
            {/if}
            <div class="text-center text-secondary mt-3">
                已有账户？ <a href="/auth/login" tabindex="-1">点击登录</a>
            </div>
        </div>
    </div>
    <div class="col-12 col-lg-6 col-xl-8 d-none d-lg-block">
        <div class="bg-cover h-100 min-vh-100" style="background-image: url(https://source.unsplash.com/random/1920x1080/?nature,water)"></div>
    </div>
</div>

{if $public_setting['enable_reg_captcha']}
    {include file='captcha/js.tpl'}
{/if}

{include file='footer.tpl'}
