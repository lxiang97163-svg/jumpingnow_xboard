<div class="modal modal-blur fade" id="success-dialog" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-success"></div>
            <div class="modal-body text-center py-4">
                <i class="ph ph-check-circle text-success" style="font-size: 3.5rem;"></i>
                <p id="success-message" class="text-secondary mt-3">成功</p>
            </div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="row">
                        <div class="col">
                            <a id="success-confirm" href="" class="btn w-100" data-bs-dismiss="modal">
                                好
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal modal-blur fade" id="fail-dialog" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-danger"></div>
            <div class="modal-body text-center py-4">
                <i class="ph ph-x-circle text-danger" style="font-size: 3.5rem;"></i>
                <p id="fail-message" class="text-secondary mt-3">失败</p>
            </div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="row">
                        <div class="col">
                            <a href="" class="btn btn-danger w-100" data-bs-dismiss="modal">
                                确认
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="//{$config['jsdelivr_url']}/npm/@tabler/core@latest/dist/js/tabler.min.js"></script>

<script>
    let successDialog = new tabler.bootstrap.Modal(document.getElementById('success-dialog'));
    let failDialog = new tabler.bootstrap.Modal(document.getElementById('fail-dialog'));

    htmx.on("htmx:afterRequest", function(evt) {
        if (evt.detail.xhr.getResponseHeader('HX-Redirect'))
        {
            return;
        }

        let res = JSON.parse(evt.detail.xhr.response);

        if (evt.detail.elt.id === 'send-verify-email') {
            document.getElementById('send-verify-email').disabled = true;
        }

        if (res.ret === 1) {
            document.getElementById("success-message").innerHTML = res.msg;
            successDialog.show();
        } else {
            document.getElementById("fail-message").innerHTML = res.msg;
            failDialog.show();
        }
    });

    // Theme Toggle Logic
    const themeStorageKey = 'tablerTheme';
    
    function toggleTheme() {
        const currentTheme = localStorage.getItem(themeStorageKey) || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-bs-theme', newTheme);
        document.body.setAttribute('data-bs-theme', newTheme);
        localStorage.setItem(themeStorageKey, newTheme);
        
        // Update icons if they exist
        updateThemeIcon(newTheme);
    }

    function updateThemeIcon(theme) {
        const icon = document.getElementById('theme-icon');
        if (icon) {
            if (theme === 'dark') {
                icon.classList.remove('ph-moon');
                icon.classList.add('ph-sun');
            } else {
                icon.classList.remove('ph-sun');
                icon.classList.add('ph-moon');
            }
        }
    }
    
    // Init icon on load
    document.addEventListener('DOMContentLoaded', () => {
        const savedTheme = localStorage.getItem(themeStorageKey) || 'light';
        updateThemeIcon(savedTheme);
    });
</script>

{include file='live_chat.tpl'}
{include file='telemetry.tpl'}

</body>
</html>
