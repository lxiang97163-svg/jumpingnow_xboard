<div class="card-body">
    <h4 class="card-title">Cryptomus</h4>
    <form class="cryptomus" name="cryptomus" method="post">
        <button class="btn btn-primary w-100"
                hx-post="/user/payment/purchase/cryptomus" hx-swap="none"
                hx-vals='js:{
                    price: {$invoice->price},
                    invoice_id: {$invoice->id},
                    type: "cryptomus",
                    redir: window.location.href
                }'>
            <i class="ph ph-currency-btc me-2"></i> 支付
        </button>
    </form>
</div>
