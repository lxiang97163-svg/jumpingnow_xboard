<div class="card-body">
    <h4 class="card-title">EPay</h4>
    <form class="epay" name="epay" method="post">
        <div class="d-flex flex-wrap gap-2">
            {if $public_setting['epay_alipay']}
            <button class="btn btn-light p-2"
                    hx-post="/user/payment/purchase/epay" hx-swap="none"
                    hx-vals='js:{
                        invoice_id: {$invoice->id},
                        type: "alipay",
                        redir: window.location.href
                    }'>
                <img src="/images/alipay.svg" height="40px" alt="Alipay"/>
            </button>
            {/if}
            {if $public_setting['epay_wechat']}
            <button class="btn btn-light p-2"
                    hx-post="/user/payment/purchase/epay" hx-swap="none"
                    hx-vals='js:{
                        invoice_id: {$invoice->id},
                        type: "wxpay",
                        redir: window.location.href
                    }'>
                <img src="/images/wechat.svg" height="40px" alt="WeChat Pay"/>
            </button>
            {/if}
            {if $public_setting['epay_qq']}
            <button class="btn btn-light p-2"
                    hx-post="/user/payment/purchase/epay" hx-swap="none"
                    hx-vals='js:{
                        invoice_id: {$invoice->id},
                        type: "qqpay",
                        redir: window.location.href
                    }'>
                <img src="/images/qq.svg" height="40px" alt="QQ Pay"/>
            </button>
            {/if}
            {if $public_setting['epay_usdt']}
            <button class="btn btn-light p-2"
                    hx-post="/user/payment/purchase/epay" hx-swap="none"
                    hx-vals='js:{
                        invoice_id: {$invoice->id},
                        type: "usdt",
                        redir: window.location.href
                    }'>
                <img src="/images/tether.svg" height="40px" alt="USDT"/>
            </button>
            {/if}
        </div>
    </form>
</div>
