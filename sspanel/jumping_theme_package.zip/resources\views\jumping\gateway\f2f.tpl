<script src="//{$config['jsdelivr_url']}/npm/jquery/dist/jquery.min.js"></script>

<div class="card-body">
    <h4 class="card-title">支付宝当面付</h4>
    <div id="f2f-qrcode" class="text-center my-3"></div>
    <button class="btn btn-primary w-100" id="f2fpay-button" type="button" onclick="f2fpay();">
        <i class="ph ph-qr-code me-2"></i> 生成付款二维码
    </button>
</div>

<script>
    let f2fQrcode = $('#f2fpay-button');

    function f2fpay() {
        $.ajax({
            type: "POST",
            url: "/user/payment/purchase/f2f",
            dataType: "json",
            data: {
                invoice_id: {$invoice->id},
            },
            success: (data) => {
                if (data.ret === 1) {
                    f2fQrcode.replaceWith('<div class="text-center text-muted mb-2">请使用支付宝扫码支付</div>');
                    new QRCode("f2f-qrcode", {
                        text: data.qrcode,
                        width: 200,
                        height: 200,
                        colorDark: '#000000',
                        colorLight: '#ffffff',
                        correctLevel: QRCode.CorrectLevel.H,
                    });
                    $('#f2f-qrcode').after('<div class="text-center mt-3 text-muted">支付成功后请手动刷新页面</div>');
                } else {
                    $('#fail-message').text(data.msg);
                    $('#fail-dialog').modal('show');
                }
            }
        })
    }
</script>
