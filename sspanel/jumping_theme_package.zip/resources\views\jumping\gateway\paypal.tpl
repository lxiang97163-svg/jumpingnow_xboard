<script src="https://www.paypal.com/sdk/js?client-id={$public_setting['paypal_client_id']}&currency={$public_setting['paypal_currency']}"></script>

<div class="card-body">
    <h4 class="card-title">PayPal</h4>
    <div id="paypal-button-container" class="mt-3"></div>
</div>

<script>
    paypal.Buttons({
        createOrder() {
            return fetch("/user/payment/purchase/paypal", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    invoice_id: {$invoice->id},
                }),
            })
                .then((response) => response.json())
                .then((order) => order.id);
        },
        onApprove() {
            window.setTimeout(location.href = '/user/invoice', {$config['jump_delay']});
        }
    }).render('#paypal-button-container');
</script>
