<div class="card-body">
    <h4 class="card-title">支付宝当面付</h4>
    <input hidden id="amount-smogate" name="amount-smogate" value="{$invoice->price}">
    <input hidden id="invoice_id" name="invoice_id" value="{$invoice->id}">
    <div id="smogate-qrcode" class="text-center my-3"></div>
    <button class="btn btn-primary w-100" id="smogate-button" type="button" onclick="smogate();">
        <i class="ph ph-qr-code me-2"></i> 充值
    </button>
</div>

<script>
    let pid = 0;
    let flag = false;
    let paymentButton = $('#smogate-button');

    function smogate() {
        paymentButton.attr('disabled', true);
        $.ajax({
            type: "POST",
            url: "/user/payment/purchase/smogate",
            dataType: "json",
            data: {
                amount: $('#amount-smogate').val(),
                invoice_id: $('#invoice_id').val(),
            },
            success: (data) => {
                paymentButton.attr('disabled', false);
                if (data.ret === 1) {
                    pid = data.pid;
                    paymentButton.replaceWith('<div class="text-center text-muted mb-2">请使用支付宝扫码支付</div>');
                    new QRCode("smogate-qrcode", {
                        render: "canvas",
                        width: 200,
                        height: 200,
                        text: encodeURI(data.qrcode)
                    });
                    
                    $('#smogate-qrcode').after('<div class="text-center mt-3 text-muted">支付成功后请手动刷新页面</div>');
                } else {
                    $('#fail-message').text(data.msg);
                    $('#fail-dialog').modal('show');
                }
            },
            error: () => {
                paymentButton.attr('disabled', false);
            }
        })
    }
</script>
