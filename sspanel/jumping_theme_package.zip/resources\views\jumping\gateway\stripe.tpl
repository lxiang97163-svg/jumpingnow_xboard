<link rel="stylesheet"
      href="//{$config['jsdelivr_url']}/npm/@tabler/core@latest/dist/css/tabler-payments.min.css">

<div class="card-body">
    <h4 class="card-title">Stripe</h4>
    <p class="text-secondary">可以使用带有
        <span class="payment payment-xs payment-provider-unionpay me-1"></span>
        <span class="payment payment-xs payment-provider-mastercard me-1"></span>
        <span class="payment payment-xs payment-provider-visa me-1"></span>
        等标识的信用卡或借记卡
    </p>
    <div class="form-group">
        <button class="btn btn-primary w-100"
            hx-post="/user/payment/purchase/stripe" hx-swap="none"
            hx-vals='js:{
                invoice_id: {$invoice->id},
            }'>
            <i class="ph ph-credit-card me-2"></i> 立即支付
        </button>
    </div>
</div>
