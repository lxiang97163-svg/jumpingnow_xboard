<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{$config['appName']} - 极速互联，超越极限</title>
    <link rel="stylesheet" href="/theme/jumping/css/style.css">
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
</head>
<body class="landing-page">

    <div class="cursor-blob" id="cursorBlob"></div>
    <canvas id="particles-js"></canvas>

    <nav class="navbar-landing">
        <div class="logo">{$config['appName']}</div>
        <div class="nav-links">
            <a href="/user/shop">订阅套餐</a>
            <a href="/user/node">节点列表</a>
            <a href="/user/docs">使用教程</a>
        </div>
        {if $user->isLogin}
            <a href="/user" class="btn-cta">用户中心</a>
        {else}
            <a href="/auth/login" class="btn-cta">登录 / 注册</a>
        {/if}
    </nav>

    <div class="landing-container">
        <!-- Left Content: Hero & Actions -->
        <div class="content-left">
            <h1 class="hero-title">速度，<br>超越极限。</h1>
            <p class="hero-desc">
                体验未来的连接方式。IEPL 专线直连，4K 秒开，绝对隐私保护。<br>
                全球 80+ 节点，解锁 Netflix, Disney+, ChatGPT。
            </p>
            <div class="hero-actions">
                {if $user->isLogin}
                    <a href="/user/shop" class="btn-primary-landing">立即开始订阅</a>
                {else}
                    <a href="/auth/register" class="btn-primary-landing">立即开始订阅</a>
                {/if}
            </div>

            <!-- Compact Download Widget -->
            <div class="download-widget">
                <div class="dw-header">客户端下载 & 教程</div>
                <div class="dw-icons">
                    <button class="dw-btn active" onclick="selectClient('win')" title="Windows"><i class="ph ph-windows-logo"></i></button>
                    <button class="dw-btn" onclick="selectClient('mac')" title="macOS"><i class="ph ph-apple-logo"></i></button>
                    <button class="dw-btn" onclick="selectClient('android')" title="Android"><i class="ph ph-android-logo"></i></button>
                    <button class="dw-btn" onclick="selectClient('ios')" title="iOS"><i class="ph ph-app-store-logo"></i></button>
                </div>
                <div class="dw-info">
                    <span id="client-name">Clash Verge Rev</span>
                    <a href="/user/docs" class="dw-link">点击下载 <i class="ph ph-arrow-right"></i></a>
                </div>
            </div>
        </div>

        <!-- Right Content: Features Grid -->
        <div class="content-right">
            <div class="feature-grid-compact">
                <div class="feature-card-mini">
                    <div class="fc-icon"><i class="ph ph-rocket-launch"></i></div>
                    <div class="fc-content">
                        <div class="fc-title">极速体验</div>
                        <div class="fc-desc">IEPL 内网专线，低延迟游戏，4K 视频秒开。</div>
                    </div>
                </div>
                <div class="feature-card-mini">
                    <div class="fc-icon"><i class="ph ph-shield-check"></i></div>
                    <div class="fc-content">
                        <div class="fc-title">隐私安全</div>
                        <div class="fc-desc">零日志记录，军用级 AES-256 加密传输。</div>
                    </div>
                </div>
                <div class="feature-card-mini">
                    <div class="fc-icon"><i class="ph ph-globe-hemisphere-west"></i></div>
                    <div class="fc-content">
                        <div class="fc-title">全球解锁</div>
                        <div class="fc-desc">解锁 Netflix, Disney+, HBO, ChatGPT 等服务。</div>
                    </div>
                </div>
                <div class="feature-card-mini">
                    <div class="fc-icon"><i class="ph ph-devices"></i></div>
                    <div class="fc-content">
                        <div class="fc-title">全平台支持</div>
                        <div class="fc-desc">iOS, Android, Windows, macOS 完美兼容。</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Client Selection Logic
        const clients = {
            'win': 'Clash Verge Rev',
            'mac': 'ClashX Pro',
            'android': 'Clash for Android',
            'ios': 'Shadowrocket'
        };

        function selectClient(os) {
            // Update buttons
            document.querySelectorAll('.dw-btn').forEach(btn => btn.classList.remove('active'));
            event.currentTarget.classList.add('active');
            
            // Update text
            document.getElementById('client-name').textContent = clients[os];
        }

        // Particle Effect
        const canvas = document.getElementById('particles-js');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const particles = [];
        for(let i=0; i<40; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                vx: (Math.random() - 0.5) * 0.3,
                vy: (Math.random() - 0.5) * 0.3,
                size: Math.random() * 2
            });
        }

        function animate() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
            particles.forEach(p => {
                p.x += p.vx;
                p.y += p.vy;
                if(p.x < 0 || p.x > canvas.width) p.vx *= -1;
                if(p.y < 0 || p.y > canvas.height) p.vy *= -1;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });
            requestAnimationFrame(animate);
        }
        animate();

        // Mouse Blob
        const blob = document.getElementById('cursorBlob');
        document.addEventListener('mousemove', (e) => {
            blob.style.left = e.clientX + 'px';
            blob.style.top = e.clientY + 'px';
        });
    </script>
</body>
</html>
