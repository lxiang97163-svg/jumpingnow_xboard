<div class="modal modal-blur fade" id="success-dialog" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-success"></div>
            <div class="modal-body text-center py-4">
                <i class="ph ph-check-circle text-success" style="font-size: 3.5rem;"></i>
                <p id="success-message" class="text-secondary mt-3">成功</p>
            </div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="row">
                        <div class="col">
                            <button type="button" id="success-confirm" class="btn w-100" data-bs-dismiss="modal">
                                好
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal modal-blur fade" id="fail-dialog" role="dialog">
    <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
        <div class="modal-content">
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <div class="modal-status bg-danger"></div>
            <div class="modal-body text-center py-4">
                <i class="ph ph-x-circle text-danger" style="font-size: 3.5rem;"></i>
                <p id="fail-message" class="text-secondary mt-3">失败</p>
            </div>
            <div class="modal-footer">
                <div class="w-100">
                    <div class="row">
                        <div class="col">
                            <a href="" class="btn btn-danger w-100" data-bs-dismiss="modal">
                                确认
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<footer class="footer footer-transparent d-print-none">
    <div class="container-xl">
        <div class="row text-center align-items-center flex-row-reverse">
            <div class="col-lg-auto ms-lg-auto">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        Powered by <a href="/staff" class="link-secondary">SSPanel-UIM</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-lg-auto mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                    <li class="list-inline-item">
                        Theme Jumping
                    </li>
                </ul>
            </div>
        </div>
    </div>
</footer>
</div>
</div>
<script src="//{$config['jsdelivr_url']}/npm/@tabler/core@latest/dist/js/tabler.min.js"></script>
<script>
    function showToast(message, type = 'success') {
        const toast = document.createElement('div');
        const bgColor = type === 'danger' ? 'bg-danger' : 'bg-success';
        toast.className = 'position-fixed top-0 start-50 translate-middle-x mt-3 ' + bgColor + ' text-white px-4 py-2 rounded shadow';
        toast.style.zIndex = '9999';
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(function() {
            toast.remove();
        }, 2000);
    }

    window.addEventListener('load', function() {
        if (typeof tabler !== 'undefined' && tabler.bootstrap) {
            window.successDialog = new tabler.bootstrap.Modal(document.getElementById('success-dialog'));
            window.failDialog = new tabler.bootstrap.Modal(document.getElementById('fail-dialog'));
        }
        
        // Init theme icon
        const themeStorageKey = 'tablerTheme';
        const savedTheme = localStorage.getItem(themeStorageKey) || 'light';
        updateThemeIcon(savedTheme);
    });

    function toggleTheme() {
        const themeStorageKey = 'tablerTheme';
        const currentTheme = localStorage.getItem(themeStorageKey) || 'light';
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-bs-theme', newTheme);
        document.body.setAttribute('data-bs-theme', newTheme);
        localStorage.setItem(themeStorageKey, newTheme);
        updateThemeIcon(newTheme);
    }

    function updateThemeIcon(theme) {
        const icon = document.getElementById('theme-icon');
        if (icon) {
            if (theme === 'dark') {
                icon.classList.remove('ph-moon');
                icon.classList.add('ph-sun');
            } else {
                icon.classList.remove('ph-sun');
                icon.classList.add('ph-moon');
            }
        }
    }

    // Initialize clipboard functionality
    if (typeof ClipboardJS !== 'undefined' && document.querySelector('.copy')) {
        let clipboard = new ClipboardJS('.copy');
        clipboard.on('success', function(e) {
            showToast('已复制到剪切板');
            e.clearSelection();
        });
        
        clipboard.on('error', function(e) {
            const text = e.trigger.getAttribute('data-clipboard-text');
            if (text) {
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(text).then(function() {
                        showToast('已复制到剪切板');
                    }).catch(function(err) {
                        prompt('复制失败，请手动复制以下内容：', text);
                    });
                } else {
                    prompt('复制失败，请手动复制以下内容：', text);
                }
            } else {
                showToast('复制失败，请重试', 'danger');
            }
        });
    }

    htmx.on("htmx:afterRequest", function(evt) {
        if (evt.detail.xhr.getResponseHeader('HX-Refresh') === 'true' ||
            evt.detail.xhr.getResponseHeader('HX-Trigger'))
        {
            return;
        }

        try {
            let res = JSON.parse(evt.detail.xhr.response);

            if (typeof res.data !== 'undefined') {
                for (let key in res.data) {
                    if (res.data.hasOwnProperty(key)) {
                        if (key === "ga-url" && typeof qrcode !== 'undefined') {
                            qrcode.clear();
                            qrcode.makeCode(res.data[key]);
                            continue;
                        }

                        if (key === "last-checkin-time") {
                            const checkInBtn = document.getElementById("check-in");
                            checkInBtn.textContent = "已签到";
                            checkInBtn.disabled = true;
                            continue;
                        }

                        const element = document.getElementById(key);
                        if (element) {
                            if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") {
                                element.value = res.data[key];
                            } else {
                                element.textContent = res.data[key];
                            }
                        }
                    }
                }
            }

            const isSuccess = res.ret === 1;
            const messageId = isSuccess ? "success-message" : "fail-message";
            const dialog = isSuccess ? window.successDialog : window.failDialog;
            
            document.getElementById(messageId).textContent = res.msg;
            if (dialog) {
                dialog.show();
            } else {
                showToast(res.msg, isSuccess ? 'success' : 'danger');
            }
        } catch (e) {
            console.error("Failed to parse HTMX response:", e);
        }
    });
</script>
<script>console.table([['数据库查询', '执行时间'], ['{count($queryLog)} 次', '{$optTime} ms']])</script>

{include file='live_chat.tpl'}
{include file='telemetry.tpl'}

</body>
</html>
