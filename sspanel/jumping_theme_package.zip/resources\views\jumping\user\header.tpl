<!doctype html>
<html lang="zh">

<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover"/>
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <meta name="referrer" content="never">
    <title>{$config['appName']}</title>
    <!-- CSS files -->
    <link href="//{$config['jsdelivr_url']}/npm/@tabler/core@latest/dist/css/tabler.min.css" rel="stylesheet"/>
    <link href="/theme/jumping/css/style.css" rel="stylesheet"/>
    <!-- Phosphor Icons -->
    <script src="https://unpkg.com/@phosphor-icons/web"></script>
    <!-- JS files -->
    <script src="/assets/js/fuck.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/qrcode_js@latest/qrcode.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/clipboard@latest/dist/clipboard.min.js"></script>
    <script src="//{$config['jsdelivr_url']}/npm/htmx.org@latest/dist/htmx.min.js"></script>
    <style>
        .navbar-vertical { background: #fff; border-right: 1px solid #e6e8eb; }
        .nav-link-title { font-weight: 500; }
        .page-wrapper { background: #f4f6f8; min-height: 100vh; }
        
        [data-bs-theme="dark"] .navbar-vertical {
            background: #1e293b;
            border-right: 1px solid #334155;
        }
    </style>
</head>

<body class="dashboard-body">
<div class="page">
    <!-- Sidebar -->
    <aside class="navbar navbar-vertical navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#sidebar-menu">
                <span class="navbar-toggler-icon"></span>
            </button>
            <h1 class="navbar-brand navbar-brand-autodark">
                <a href="/user" style="text-decoration: none; color: #007aff; font-weight: 800; display: flex; align-items: center; gap: 10px;">
                    <img src="/images/uim-logo-round_48x48.png" height="32" alt="Logo">
                    {$config['appName']}
                </a>
            </h1>
            <div class="navbar-nav flex-row d-lg-none">
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link d-flex lh-1 text-reset p-0" data-bs-toggle="dropdown">
                        <span class="avatar avatar-sm" style="background-image: url({$user->dice_bear})"></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                        <a href="/user/profile" class="dropdown-item">账户</a>
                        <a href="/user/logout" class="dropdown-item">登出</a>
                    </div>
                </div>
            </div>
            <div class="collapse navbar-collapse" id="sidebar-menu">
                <ul class="navbar-nav pt-lg-3">
                    <li class="nav-item">
                        <a class="nav-link" href="/user">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-house"></i></span>
                            <span class="nav-link-title">主页</span>
                        </a>
                    </li>
                    
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-base" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-user"></i></span>
                            <span class="nav-link-title">我的</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/user/profile">
                                <i class="ph ph-info me-2"></i> 账户
                            </a>
                            <a class="dropdown-item" href="/user/edit">
                                <i class="ph ph-pencil-simple me-2"></i> 资料
                            </a>
                            <a class="dropdown-item" href="/user/invite">
                                <i class="ph ph-users me-2"></i> 邀请
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-use" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-paper-plane-tilt"></i></span>
                            <span class="nav-link-title">使用</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/user/server">
                                <i class="ph ph-list-dashes me-2"></i> 节点
                            </a>
                            <a class="dropdown-item" href="/user/rate">
                                <i class="ph ph-chart-bar me-2"></i> 流量倍率
                            </a>
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-support" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-lifebuoy"></i></span>
                            <span class="nav-link-title">支援</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/user/announcement">
                                <i class="ph ph-megaphone me-2"></i> 公告
                            </a>
                            {if $public_setting['enable_ticket']}
                                <a class="dropdown-item" href="/user/ticket">
                                    <i class="ph ph-ticket me-2"></i> 工单
                                </a>
                            {/if}
                            {if $public_setting['display_docs'] && (! $public_setting['display_docs_only_for_paid_user'] || $user->class !== 0)}
                                <a class="dropdown-item" href="/user/docs">
                                    <i class="ph ph-book me-2"></i> 文档
                                </a>
                            {/if}
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-audit" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-shield-check"></i></span>
                            <span class="nav-link-title">审计</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/user/detect">
                                <i class="ph ph-prohibit me-2"></i> 规则
                            </a>
                            {if $public_setting['display_detect_log']}
                                <a class="dropdown-item" href="/user/detect/log">
                                    <i class="ph ph-notebook me-2"></i> 日志
                                </a>
                            {/if}
                        </div>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#navbar-store" data-bs-toggle="dropdown" role="button" aria-expanded="false">
                            <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-storefront"></i></span>
                            <span class="nav-link-title">商店</span>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="/user/product">
                                <i class="ph ph-shopping-bag me-2"></i> 商品
                            </a>
                            <a class="dropdown-item" href="/user/order">
                                <i class="ph ph-receipt me-2"></i> 订单
                            </a>
                            <a class="dropdown-item" href="/user/invoice">
                                <i class="ph ph-file-text me-2"></i> 账单
                            </a>
                            <a class="dropdown-item" href="/user/money">
                                <i class="ph ph-wallet me-2"></i> 余额
                            </a>
                        </div>
                    </li>

                    {if $user->is_admin}
                        <li class="nav-item">
                            <a class="nav-link" href="/admin">
                                <span class="nav-link-icon d-md-none d-lg-inline-block"><i class="ph ph-gear"></i></span>
                                <span class="nav-link-title">站点管理</span>
                            </a>
                        </li>
                    {/if}
                </ul>
                
                <!-- Bottom User Menu (Desktop) -->
                <div class="mt-auto d-none d-lg-block mb-3">
                    <div class="dropdown">
                        <a href="#" class="d-flex align-items-center text-reset text-decoration-none" data-bs-toggle="dropdown">
                            <span class="avatar avatar-sm" style="background-image: url({$user->dice_bear})"></span>
                            <div class="d-none d-xl-block ps-2">
                                <div>{$user->user_name}</div>
                                <div class="mt-1 small text-muted">{$user->email}</div>
                            </div>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                            <a href="#" class="dropdown-item" onclick="toggleTheme(); return false;">
                                <i class="ph ph-moon me-2" id="theme-icon"></i> 切换主题
                            </a>
                            <a href="/user/logout" class="dropdown-item">登出</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </aside>

    <div class="page-wrapper">
        <!-- Page header -->
        <div class="page-header d-print-none">
            <div class="container-xl">
                <div class="row g-2 align-items-center">
                    <div class="col">
                        <!-- Page pre-title -->
                        <div class="page-pretitle">
                            概览
                        </div>
                        <h2 class="page-title">
                            欢迎回来, {$user->user_name}
                        </h2>
                    </div>
                    <div class="col-auto ms-auto d-print-none">
                        <div class="btn-list">
                            <a href="/user/ticket/create" class="btn btn-white d-none d-sm-inline-block">
                                <i class="ph ph-lifebuoy me-2"></i> 联系客服
                            </a>
                            <a href="/user/product" class="btn btn-primary d-none d-sm-inline-block">
                                <i class="ph ph-lightning me-2"></i> 快速连接
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
