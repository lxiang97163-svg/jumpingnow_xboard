{include file='user/header.tpl'}

<div class="page-wrapper">
    <div class="container-xl">
        <div class="page-header d-print-none text-white">
            <div class="row align-items-center">
                <div class="col">
                    <h2 class="page-title">
                        <span class="home-title">商店</span>
                    </h2>
                    <div class="page-pretitle my-3">
                        <span class="home-subtitle">选择最适合您的订阅计划</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="page-body">
        <div class="container-xl">
            <div class="row row-cards">
                <div class="col-12">
                    <div class="card card-metron">
                        <ul class="nav nav-tabs nav-fill" data-bs-toggle="tabs">
                            <li class="nav-item">
                                <a href="#tabp" class="nav-link active" data-bs-toggle="tab">
                                    <i class="ph ph-arrows-clockwise icon"></i>
                                    &nbsp;周期订阅
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#bandwidth" class="nav-link" data-bs-toggle="tab">
                                    <i class="ph ph-database icon"></i>
                                    &nbsp;流量包
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#time" class="nav-link" data-bs-toggle="tab">
                                    <i class="ph ph-clock icon"></i>
                                    &nbsp;时间包
                                </a>
                            </li>
                        </ul>
                        <div class="card-body bg-light">
                            <div class="tab-content">
                                <div class="tab-pane active show" id="tabp">
                                    <div class="row row-cards">
                                        {foreach $tabps as $tabp}
                                            <div class="col-md-4 col-lg-3 col-sm-12">
                                                <div class="shop-card-modern {if $tabp->stock === -1}featured{/if}">
                                                    {if $tabp->stock === -1}
                                                    <div class="card-badge">推荐</div>
                                                    {/if}
                                                    <div class="shop-body">
                                                        <div class="plan-name">{$tabp->name}</div>
                                                        <div class="plan-price">
                                                            {$tabp->price} <span>CNY</span>
                                                        </div>
                                                        <ul class="features-list">
                                                            <li>
                                                                <i class="ph ph-crown"></i>
                                                                Lv. {$tabp->content->class} 会员权益
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-calendar-check"></i>
                                                                {$tabp->content->class_time} 天有效期
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-database"></i>
                                                                {$tabp->content->bandwidth} GB 流量
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-lightning"></i>
                                                                {if $tabp->content->speed_limit === '0'}
                                                                    不限速
                                                                {else}
                                                                    {$tabp->content->speed_limit} Mbps 速率
                                                                {/if}
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-devices"></i>
                                                                {if $tabp->content->ip_limit === '0'}
                                                                    不限设备数
                                                                {else}
                                                                    {$tabp->content->ip_limit} 台设备同时在线
                                                                {/if}
                                                            </li>
                                                        </ul>
                                                        {if $tabp->stock === -1 || $tabp->stock > 0}
                                                            <a href="/user/order/create?product_id={$tabp->id}"
                                                               class="btn btn-primary btn-plan">立即购买</a>
                                                        {else}
                                                            <button class="btn btn-secondary btn-plan" disabled>已售罄</button>
                                                        {/if}
                                                    </div>
                                                </div>
                                            </div>
                                        {/foreach}
                                    </div>
                                </div>
                                <div class="tab-pane show" id="bandwidth">
                                    <div class="row row-cards">
                                        {foreach $bandwidths as $bandwidth}
                                            <div class="col-md-4 col-lg-3 col-sm-12">
                                                <div class="shop-card-modern">
                                                    <div class="shop-body">
                                                        <div class="plan-name">{$bandwidth->name}</div>
                                                        <div class="plan-price">
                                                            {$bandwidth->price} <span>CNY</span>
                                                        </div>
                                                        <ul class="features-list">
                                                            <li>
                                                                <i class="ph ph-database-plus"></i>
                                                                增加 {$bandwidth->content->bandwidth} GB 流量
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-info"></i>
                                                                不重置到期时间
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-check-circle"></i>
                                                                即时生效
                                                            </li>
                                                        </ul>
                                                        {if $bandwidth->stock === -1 || $bandwidth->stock > 0}
                                                            <a href="/user/order/create?product_id={$bandwidth->id}"
                                                               class="btn btn-primary btn-plan">立即购买</a>
                                                        {else}
                                                            <button class="btn btn-secondary btn-plan" disabled>已售罄</button>
                                                        {/if}
                                                    </div>
                                                </div>
                                            </div>
                                        {/foreach}
                                    </div>
                                </div>
                                <div class="tab-pane show" id="time">
                                    <div class="row row-cards">
                                        {foreach $times as $time}
                                            <div class="col-md-4 col-lg-3 col-sm-12">
                                                <div class="shop-card-modern">
                                                    <div class="shop-body">
                                                        <div class="plan-name">{$time->name}</div>
                                                        <div class="plan-price">
                                                            {$time->price} <span>CNY</span>
                                                        </div>
                                                        <ul class="features-list">
                                                            <li>
                                                                <i class="ph ph-crown"></i>
                                                                Lv. {$time->content->class} 会员权益
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-calendar-plus"></i>
                                                                增加 {$time->content->class_time} 天时长
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-lightning"></i>
                                                                {if $time->content->speed_limit === '0'}
                                                                    不限速
                                                                {else}
                                                                    {$time->content->speed_limit} Mbps 速率
                                                                {/if}
                                                            </li>
                                                            <li>
                                                                <i class="ph ph-devices"></i>
                                                                {if $time->content->ip_limit === '0'}
                                                                    不限设备数
                                                                {else}
                                                                    {$time->content->ip_limit} 台设备同时在线
                                                                {/if}
                                                            </li>
                                                        </ul>
                                                        {if $time->stock === -1 || $time->stock > 0}
                                                            <a href="/user/order/create?product_id={$time->id}"
                                                               class="btn btn-primary btn-plan">立即购买</a>
                                                        {else}
                                                            <button class="btn btn-secondary btn-plan" disabled>已售罄</button>
                                                        {/if}
                                                    </div>
                                                </div>
                                            </div>
                                        {/foreach}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {include file='user/footer.tpl'}
